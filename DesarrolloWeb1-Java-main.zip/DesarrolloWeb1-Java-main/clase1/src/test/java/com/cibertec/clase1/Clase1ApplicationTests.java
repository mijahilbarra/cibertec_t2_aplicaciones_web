package com.cibertec.clase1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
