package com.cibertec.clase3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase3Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase3Application.class, args);
	}

}
